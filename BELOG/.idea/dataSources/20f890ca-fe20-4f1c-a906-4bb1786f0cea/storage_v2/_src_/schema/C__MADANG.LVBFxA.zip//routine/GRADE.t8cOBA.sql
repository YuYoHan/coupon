create function grade(custId number)
return varchar2
is 
    result varchar2(30);
    sumPrice number;
begin
    sumPrice := 0;
    select sum(saleprice) into sumPrice from orders o
    join customer c on c.custid = o.custId;
    if sumPrice >= 20000 then
        result := '우수';
    else
        result := '보통';
    end if;
    return result;
end;
/

