create trigger MEMBERS_TRIGGER
    before insert
    on MEMBERS
    for each row
BEGIN
    SELECT members_seq.NEXTVAL INTO :NEW.userId FROM dual;
END;
/

