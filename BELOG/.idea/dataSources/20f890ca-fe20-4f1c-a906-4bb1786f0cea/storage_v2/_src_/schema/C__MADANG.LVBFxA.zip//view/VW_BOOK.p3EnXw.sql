create view VW_BOOK as
select "BOOKID","BOOKNAME","PRICE","PUBLISHER" from book where bookName like '%축구%'
/

