create trigger TG_UPDATE
    after update
    on 입고
    for each row
declare
begin
    update 상품 set 재고수량 = 재고수량 - :old.입고수량 + :new.입고수량
    where 상품번호 = :old.상품번호;
end;
/

