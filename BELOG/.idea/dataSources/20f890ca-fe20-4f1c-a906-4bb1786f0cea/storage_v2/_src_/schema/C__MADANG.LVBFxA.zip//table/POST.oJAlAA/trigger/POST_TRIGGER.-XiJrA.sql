create trigger POST_TRIGGER
    before insert
    on POST
    for each row
BEGIN
    SELECT post_id_seq.NEXTVAL
    INTO :new.post_id
    FROM dual;
END;
/

