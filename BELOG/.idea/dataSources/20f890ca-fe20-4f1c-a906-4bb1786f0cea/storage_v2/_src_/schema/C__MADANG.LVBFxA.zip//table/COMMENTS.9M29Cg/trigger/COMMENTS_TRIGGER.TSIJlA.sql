create trigger COMMENTS_TRIGGER
    before insert
    on COMMENTS
    for each row
BEGIN
    SELECT comment_id_seq.NEXTVAL
    INTO :new.comment_id
    FROM dual;
END;
/

