create function margin(saleprice number)
return number
is 
    result number;
begin
    if saleprcie >= 30000 then
        result := saleprice * 0.1;
    else 
        result := saleprice * 0.05;
    end if;
    return result;
end;
/

