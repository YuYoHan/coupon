create procedure updateBook(
    myBookId in book.bookId%TYPE,
    myPrice book.price%TYPE
)
as
begin
    update book set price = (myPrice) where bookId = (myBookId);
end;
/

