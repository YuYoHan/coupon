create view VW_EMP as
select workerId, name, job, hireDate, id
from worker
where id = 2
with read only
/

