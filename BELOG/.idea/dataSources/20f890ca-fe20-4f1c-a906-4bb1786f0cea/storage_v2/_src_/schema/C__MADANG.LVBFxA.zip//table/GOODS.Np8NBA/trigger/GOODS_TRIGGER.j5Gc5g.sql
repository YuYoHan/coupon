create trigger GOODS_TRIGGER
    before insert
    on GOODS
    for each row
BEGIN
    SELECT goods_seq.NEXTVAL INTO :NEW.numId FROM dual;
END;
/

