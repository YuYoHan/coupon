create trigger TRG_INSERT_DEPT
    after insert
    on DEPARTMENT
    for each row
declare
begin
    insert into dept_back values(:new.id, :new.name, :new.location);
end;
/

