create view VW_CUSTOMER as
select "CUSTID","NAME","ADDRESS","PHONE" from customer where address like '%대한민국%'
/

