create procedure orderBook(
    myCustId orders.custId%TYPE
)
as
    myBookName varchar2(30);
    cursor c is select distinct bookName from book b, orders o
    where b.bookId = o.bookId and custId = myCustId;
begin
    open c;
    loop
        fetch c into myBookName;
        dbms_output.put_line(myBookName);
        exit when c%NOTFOUND;
    end loop;
    close c;
end;
/

