create view VW_WORKER as
select w.workerId, w.name, d.id, w.email 
from worker w
join department d on d.id = w.id
/

