create trigger TRG_DELETE_DEPT
    after delete
    on DEPARTMENT
    for each row
declare
begin 
    delete dept_back where id = :new.id;
end;
/

