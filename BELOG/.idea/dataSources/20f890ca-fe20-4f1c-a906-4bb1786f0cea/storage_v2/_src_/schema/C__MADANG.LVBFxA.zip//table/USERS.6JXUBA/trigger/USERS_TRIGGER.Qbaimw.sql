create trigger USERS_TRIGGER
    before insert
    on USERS
    for each row
BEGIN
    SELECT user_id_seq.NEXTVAL
    INTO :new.user_id
    FROM dual;
END;
/

