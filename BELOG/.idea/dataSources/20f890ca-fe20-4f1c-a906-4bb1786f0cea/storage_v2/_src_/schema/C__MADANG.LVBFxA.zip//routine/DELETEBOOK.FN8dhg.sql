create procedure deleteBook(
    myBookId in book.bookId%TYPE
)
as
begin
    delete from book where bookId = (myBookId);
end;
/

