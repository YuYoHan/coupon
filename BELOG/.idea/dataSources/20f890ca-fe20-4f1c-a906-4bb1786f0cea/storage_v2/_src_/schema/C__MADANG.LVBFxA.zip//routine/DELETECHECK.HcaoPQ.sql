create procedure deleteCheck(
    myId department.id%TYPE
)
as
begin
    delete department where id = myId;
end;
/

