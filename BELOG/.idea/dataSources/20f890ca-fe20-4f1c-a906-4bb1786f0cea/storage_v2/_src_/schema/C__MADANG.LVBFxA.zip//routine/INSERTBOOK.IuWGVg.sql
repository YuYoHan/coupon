create procedure insertBook(
    myBookId in book.bookId%TYPE,
    myBookName book.bookName%TYPE,
    myPrice book.price%TYPE,
    myPublisher book.publisher%TYPE
)
as
begin
    insert into book values(myBookId, myBookName, myPrice, myPublisher);
end;
/

